<?php

return [
    'generic_error_key' => 'error_message',
];
