<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ReportContrlller extends Controller
{
    //
}
